﻿//using System.Collections;
using System.Collections.Generic;


int count=56;
float price=543.234f;

int stockPrice=(int)price;
Console.WriteLine("Stock Price="+stockPrice);


int count2=156;
object o=count2;
Console.WriteLine(o);

int count3=(int)o;
Console.WriteLine(count3);

/*ArrayList numbers=new ArrayList();
numbers.Add(45);
numbers.Add(67);
numbers.Add(267);
foreach( object obj in numbers){
    int temp=(int)obj;
}
*/

List<int> number2=new List<int>();
number2.Add(34);
number2.Add(14);
number2.Add(38);
number2.Add(44);
number2.Add(4);

foreach( int obj in number2){
    int temp=obj;
}





