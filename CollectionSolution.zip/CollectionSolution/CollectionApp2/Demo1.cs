namespace Transflower;
public class CollectionManager {
    public  static void ShowLINQ()
    {
        List<Element> elements = BuildList();

        // LINQ Query.
        var subset = from theElement in elements
                    where theElement.AtomicNumber < 22
                    orderby theElement.Name
                    select theElement;

        foreach (Element theElement in subset)
        {
            Console.WriteLine(theElement.Name + " " + theElement.AtomicNumber);
        }

    // Output:
    //  Calcium 20
    //  Potassium 19
    //  Scandium 21
    }
    public  static List<Element> BuildList() => new()
        {
            { new(){ Symbol="K", Name="Potassium", AtomicNumber=19}},
            { new(){ Symbol="Ca", Name="Calcium", AtomicNumber=20}},
            { new(){ Symbol="Sc", Name="Scandium", AtomicNumber=21}},
            { new(){ Symbol="Ti", Name="Titanium", AtomicNumber=22}}
        };
}