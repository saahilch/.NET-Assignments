﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace EmployeeDetails
{
    public class EmployePojo
    {
        private int id;
        private string firstname;
        private string lastname;
        private int age;
        private double salary;
        private double dailyAllowance;
        private double tax;
        public EmployePojo() { }   
        public EmployePojo(int id, string firstname, string lastname, int age, double salary, double dailyAllowance, double tax)
        {
            this.id = id;
            this.firstname = firstname;
            this.lastname = lastname;
            this.age = age;
            this.salary = salary;
            this.dailyAllowance = dailyAllowance;
            this.tax = tax;
        }
        public int Id { get { return id; }set { id = value; } }
        public string Firstname { get {  return firstname; } set {  firstname = value; } }
        public string Lastname { get { return lastname; } set {  lastname = value; } }
        public int Age { get { return age; } set { age = value; } }
        public double Salary { get {  return salary; } set {  salary = value; } }
        public double DailyAllowance { get {  return dailyAllowance; } set {  dailyAllowance = value; } }
        public double Tax { get { return tax; } set { tax = value; } }
        
        public override string ToString()
        {
            return "Id :" + this.id + "fnameName:" + this.firstname + " lsatNanme:" + this.Lastname + "Age :" + this.age + "DailyAllowance :" + this.dailyAllowance + "Tax:" + this.tax;
        }
        public override bool Equals(Object obj)
        {
            return (obj is EmployePojo) && ((EmployePojo)obj).id == id;
        }
        public double totalSal()
        {
            double sal = salary * (dailyAllowance * 22);
            return sal * 1.12 * 0.95;
        }
    
    }
}
