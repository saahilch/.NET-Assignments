﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Collections;

namespace EmployeeDetails
{
    public class Company
    {
        List<EmployePojo> employeepojo;
        //ArrayList words=new ArrayList();
        
   public Company()
        {
            this.employeepojo = new List<EmployePojo>();
        }
        public List<EmployePojo> employePojos { get { return employeepojo; } set { employeepojo = value;} }
        
    public void addEmployee(EmployePojo employePojo)
        {
            this.addEmployee(employePojo);
            
        }
        public void removeEmployee(int id)
        {

            this.removeEmployee(id);   
        }
        public void displayEmployee()
        {
            foreach (var item in employeepojo)
            {
                Console.WriteLine(employePojos);
            }
        }
       public void showEmployeeByID(int id)
        {
          Console.WriteLine(employePojos.Find(x=>x.Id==id));

        }
        public void showEmployeeByName(string name) { 

        }
        public void showSalaryById(int id)
        {
            EmployePojo emp = employeepojo.Find(x => x.Id == id);

            Console.WriteLine("Salary ="+emp.totalSal);
            
        }
        public void ShowEmployeeSal()
        {
      foreach(EmployePojo employePojo in employeepojo)
            {
                Console.WriteLine(employePojo.Firstname+" "+employePojo.Lastname+"Salary: "+employePojo.totalSal());
            }
        }
    }
    
   
}
