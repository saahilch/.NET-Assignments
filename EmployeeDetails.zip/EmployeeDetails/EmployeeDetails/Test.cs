﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDetails;

    Company cc = new Company();
    Boolean exit = false;
    while(!exit)
        {
    Console.WriteLine("1.add employee 2.show employee by id 3.display all employee 4.Enter Id to remove 5.Show Salary by id 6.Show Salary 0.Exit");
    switch (Convert.ToInt32(Console.ReadLine()))
    {
        case 1:
            Console.WriteLine("int id, string firstname, string lastname, int age, double salary, double dailyAllowance, double tax");
            EmployePojo emp = new EmployePojo(Convert.ToInt32(Console.ReadLine()), Console.ReadLine(), Console.ReadLine(), Convert.ToInt32(Console.ReadLine()), Convert.ToInt32(Console.ReadLine()), Convert.ToInt32(Console.ReadLine()), Convert.ToInt32(Console.ReadLine()));
            cc.addEmployee(emp);

            break;
        case 2:
            Console.WriteLine("Enter Employee ID to show by id");
            cc.showEmployeeByID(Convert.ToInt32(Console.ReadLine()));
           
            break;
         case 3:
            cc.displayEmployee();
            break;
         case 4:
            Console.WriteLine("Enter Employee ID To Remove");
            cc.removeEmployee(Convert.ToInt32(Console.ReadLine()));
            Console.WriteLine("Removed Successfully");
            break;
         case 5:
            Console.WriteLine("Enter ID To Show Salary");
            cc.showEmployeeByID(Convert.ToInt32(Console.ReadLine()));
            break;
         case 6:
            cc.ShowEmployeeSal();

            break;
         case 0:
            exit = true;

            break;


    }

        }
  

