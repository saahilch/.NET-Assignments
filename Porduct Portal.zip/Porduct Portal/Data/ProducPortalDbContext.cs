
namespace Data;

class ProducPortalDbContext:DbContext
{
     public ProducPortalDbContext()
     {
     }
    
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        var connectionString =@"Server=ocalhost;Database=dotnet;User=root;Password=Inspiron3520;";
        optionsBuilder.UseMySql(connectionString,ServerVersion.AutoDetect(connectionString));
    }
    public DbSet<Product> products {get; set;}
}

