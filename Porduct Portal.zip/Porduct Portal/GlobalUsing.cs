global using System.ComponentModel.DataAnnotations;
global using Microsoft.EntityFrameworkCore;
global using Models;
global using Data;