
namespace Repositories;

public class ProductRepo:IProductRepo
{

    public List<Product> GetAll()
    {  
        using(ProducPortalDbContext context= new ProducPortalDbContext())
        {
            return context.products.ToList();
        }
    }

     public Product AddProduct(Product product)
    {
        using(ProducPortalDbContext context= new ProducPortalDbContext())
        {
            context.products.Add(product);
            context.SaveChanges();
            Product prod=context.products.Where(e=> e.Title==product.Title).SingleOrDefault();
            return prod;
        }
    }

    public Product GetById(int id){
        using(var context=new ProducPortalDbContext()){
            return context.products.Find(id);
        }
    }

    public Product UpdateProduct(Product product){
        using (var context=new ProducPortalDbContext())
        {
            context.products.Update(product);
            context.SaveChanges();
            return context.products.Where(p=> p.Id==product.Id).FirstOrDefault();
        }
    }

    public void DeleteProduct(int id){
        using (var context=new ProducPortalDbContext())
        {
            context.products.Remove(context.products.Find(id));
            context.SaveChanges();
        }
    }
}