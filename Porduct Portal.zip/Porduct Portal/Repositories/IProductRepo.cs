namespace Repositories;

public interface IProductRepo
{
    public List<Product> GetAll();
    public Product AddProduct(Product product);
    public Product GetById(int id);
    public Product UpdateProduct(Product product);
    public void DeleteProduct(int id);
}