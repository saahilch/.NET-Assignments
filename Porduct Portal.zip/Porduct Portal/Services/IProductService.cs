namespace Services;

public interface IProductService
{
    public List<Product> GetAll();
    public Product AddProduct(int id, string Title, double Price, int Quantity);
    public Product GetById(int id);
    public Product UpdateProduct(int Id, string Title, double Price, int Quantity);
    public void DeleteProduct(int id);

}