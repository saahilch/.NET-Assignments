using Microsoft.AspNetCore.Http.HttpResults;
using Repositories;

namespace Services;

public class ProductServices : IProductService
{
    private IProductRepo repo;

    public ProductServices(IProductRepo _repo)
    {
        this.repo = _repo;
    }

    public List<Product> GetAll()
    {
        return repo.GetAll();
    }

    public Product AddProduct(int Id, string Title, double Price, int Quantity)
    {
        Product prod = new Product();
        prod.Id = Id;
        prod.Title = Title;
        prod.Price = Price;
        prod.Quantity = Quantity;
        return repo.AddProduct(prod);
    }

    public Product GetById(int id)
    {
        return repo.GetById(id);
    }

    public Product UpdateProduct(int Id, string Title, double Price, int Quantity)
    {
        Product product=new Product();
        product.Id=Id;
        product.Title=Title;
        product.Price=Price;
        product.Quantity=Quantity;
        if (product != null)
        {
            return repo.UpdateProduct(product);
        }
        else
        {
          throw new Exception();
        }
    }

    public void DeleteProduct(int id)
    {
        repo.DeleteProduct(id);
    }
}