using Microsoft.AspNetCore.Mvc;
using Services;

namespace controller;

public class ProductController : Controller
{
    private IProductService prodServ;

    public ProductController(IProductService ser)
    {
        prodServ = ser;
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        List<Product> list = prodServ.GetAll();
        return View(list);
    }

    [HttpGet]
    public IActionResult AddProduct()
    {
        return View();
    }
    [HttpPost]
    public IActionResult AddProduct1(int Id, string Title, double Price, int Quantity)
    {
        Product prod = prodServ.AddProduct(Id, Title, Price, Quantity);
        return View(prod);
    }

    [HttpGet]
    public IActionResult Update(int id){
     return View(prodServ.GetById(id)); 
    }

    [HttpPost]
    public IActionResult UpdateProduct(int Id, string Title, double Price, int Quantity){
        
     return View(prodServ.UpdateProduct(Id, Title, Price, Quantity)); 
    }

    [HttpGet("{id}")]
    public IActionResult DeleteProduct(int id){
     prodServ.DeleteProduct(id);
     return RedirectToAction("GetAll");
    }
}