﻿using Transflower;

CollectionManager.ShowLINQ();
Console.WriteLine("Show Result");