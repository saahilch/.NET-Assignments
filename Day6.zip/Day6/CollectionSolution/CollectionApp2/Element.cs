namespace Transflower;

public class Element{
    public string Symbol {get;set;}
    public string Name  {get;set;}
    public int AtomicNumber{get;set;}
}