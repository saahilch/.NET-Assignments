using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using EStoreWebApp.Models;

namespace EStoreWebApp.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    [HttpGet]
    public IActionResult Index()
    {
       List<Product> products=new List<Product>();
        products.Add(new Product { Id=12 , Title="Lotus", UnitPrice=23, Quantity=6000});
        products.Add(new Product { Id=13 , Title="Rose", UnitPrice=53, Quantity=500}); 
        products.Add(new Product { Id=14 , Title="Lotus", UnitPrice=23, Quantity=56});
         products.Add(new Product { Id=15 , Title="Gerbera", UnitPrice=13, Quantity=5000}); 
         products.Add(new Product { Id=16, Title="Lily", UnitPrice=3, Quantity=98});
        return Json(products);

    }
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
